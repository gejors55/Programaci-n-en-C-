#include <iostream>
using namespace std;

#include "indices.h"

void crearTabla(tIndicePalabras & tabla, const string & archivoInicial){
	tListaCadenas visitados, noVisitados;
	string archivo;
	inicializar(visitados);
	inicializar(noVisitados);
	insertar(noVisitados, archivoInicial);
	while (noVisitados.tam != 0){
		archivo = getCadena(noVisitados, noVisitados.tam - 1);
		insertar(visitados, archivo);
	}
}

void inicializar(tListaCadenas cadena){
	cadena.tam = 0;
}

void abrirArchivo(const string & archivoInicial){
	ifstream fichero;
	fichero.open(archivoInicial);


}