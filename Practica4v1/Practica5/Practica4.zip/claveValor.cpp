#include <iostream>
using namespace std;

#include "claveValor.h"

int getTamanno(const tIndicePalabras & l){
	return l.tam;
}

tRegistroIndicePalabras getRegistro(const tIndicePalabras & l, int pos){
	return l.datos[pos];
}

bool esta(const tIndicePalabras & l, const string & s){
	bool encontrado = false;
	int ini = 0, fin = l.tam -1, mitad;
	while ((ini <= fin) && !encontrado) {
		mitad = (ini + fin) / 2;
		if (s == l.datos[mitad].clave) {
			encontrado = true;
		}
		else if (s < l.datos[mitad].clave) {
			fin = mitad - 1;
		}
		else {
			ini = mitad + 1;
		}
	}
	return encontrado;
}

tListaCadenas buscar(const tIndicePalabras & l, const string & s){
	bool encontrado = false;
	int pos, ini = 0, fin = l.tam - 1, mitad;
	while (!encontrado) {
		mitad = (ini + fin) / 2;
		if (s == l.datos[mitad].clave) {
			encontrado = true;
			pos = mitad;
		}
		else if (s < l.datos[mitad].clave) {
			fin = mitad - 1;
		}
		else {
			ini = mitad + 1;
		}
	}
	return l.datos[mitad].valor;
}

void insertar(tIndicePalabras & idx, const string & palabra, const string & nombreArchivo){
	if (esta(idx, palabra)){
		insertar(buscar(idx, palabra), nombreArchivo);
	}
	else{
		int i = 0;
		while (palabra > idx.datos[i].clave && i < idx.tam){
			i++;
		}
		idx.datos[i].clave = palabra;
		idx.datos[i].valor.datos[0] = nombreArchivo;
		idx.datos[i].valor.tam++;
		idx.tam++;
	}
}

void imprimir(const tIndicePalabras & idx){
	for (int i = 0; i < idx.tam; i++){
		cout << idx.datos[i].clave << "  ";
		imprimir(idx.datos[i].valor);
	}
}


/*bool esta(const tIndicePalabras & l, const string & s){
	bool encontrado = false;
	int i = 0;
	while(!encontrado &&  i < l.tam){
		if (s == l.datos[i].clave){
			encontrado = true;
		}
		else{
			i++;
		}
	}
	return encontrado;
}

tListaCadenas buscar(const tIndicePalabras & l, const string & s){
	bool encontrado = false;
	int pos;
	int i = 0;
	while (!encontrado && i < l.tam){
		if (s == l.datos[i].clave){
			encontrado = true;
			pos = i;
		}
		else{
			i++;
		}
	}
	return l.datos[i].valor;
}

void insertar(tIndicePalabras & idx, const string & palabra, const string & nombreArchivo){
	if (esta(idx, palabra)){
		insertar(buscar(idx, palabra), nombreArchivo);
	}
	else{
		idx.datos[idx.tam].clave = palabra;
		idx.datos[idx.tam].valor.datos[0] = nombreArchivo;
		idx.datos[idx.tam].valor.tam++;
		idx.tam++;
	}
	}*/