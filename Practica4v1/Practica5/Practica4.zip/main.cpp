#include <iostream>
#include <string>

using namespace std;

int main(){
	cout << "Buscador FdI-FP" << endl << endl;
	cout << "Por favor, introduzca el nombre del fichero raiz a partir del que se crear� el �ndice: ";
	


	system("pause");
	return 0;
}