#ifndef indices_h
#define indices_h
#include <string>
#include <fstream>
using namespace std;

#include "claveValor.h"
#include "listaCadenas.h"

//A partir de archivoInicial, rellena la tabla tabla, tras haberla inicializado(a vac�a).
void crearTabla(tIndicePalabras & tabla, const string & archivoInicial);
//Inicializa tipos tListaCadenas a vacio.
void inicializar(tListaCadenas cadena);


#endif